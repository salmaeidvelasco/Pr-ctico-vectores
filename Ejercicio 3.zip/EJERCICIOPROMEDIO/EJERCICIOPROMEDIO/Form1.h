#pragma once
#include "Promedio.h"
#include <iostream>
#include "stdafx.h"

namespace EJERCICIOPROMEDIO {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	int posi=0;

	Promedio promedio1;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  bntdefinir;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txttamanio;
	private: System::Windows::Forms::TextBox^  txtnumero;
	private: System::Windows::Forms::Button^  bntingresar;
	private: System::Windows::Forms::Button^  bntcalcular;

	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtpromedio;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->bntdefinir = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txttamanio = (gcnew System::Windows::Forms::TextBox());
			this->txtnumero = (gcnew System::Windows::Forms::TextBox());
			this->bntingresar = (gcnew System::Windows::Forms::Button());
			this->bntcalcular = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtpromedio = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// bntdefinir
			// 
			this->bntdefinir->Location = System::Drawing::Point(234, 46);
			this->bntdefinir->Name = L"bntdefinir";
			this->bntdefinir->Size = System::Drawing::Size(75, 23);
			this->bntdefinir->TabIndex = 0;
			this->bntdefinir->Text = L"definir";
			this->bntdefinir->UseVisualStyleBackColor = true;
			this->bntdefinir->Click += gcnew System::EventHandler(this, &Form1::bntdefinir_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(36, 56);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(36, 87);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(42, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"numero";
			// 
			// txttamanio
			// 
			this->txttamanio->Location = System::Drawing::Point(116, 49);
			this->txttamanio->Name = L"txttamanio";
			this->txttamanio->Size = System::Drawing::Size(100, 20);
			this->txttamanio->TabIndex = 3;
			// 
			// txtnumero
			// 
			this->txtnumero->Location = System::Drawing::Point(116, 84);
			this->txtnumero->Name = L"txtnumero";
			this->txtnumero->Size = System::Drawing::Size(100, 20);
			this->txtnumero->TabIndex = 4;
			// 
			// bntingresar
			// 
			this->bntingresar->Location = System::Drawing::Point(234, 77);
			this->bntingresar->Name = L"bntingresar";
			this->bntingresar->Size = System::Drawing::Size(75, 23);
			this->bntingresar->TabIndex = 5;
			this->bntingresar->Text = L"ingresar";
			this->bntingresar->UseVisualStyleBackColor = true;
			this->bntingresar->Click += gcnew System::EventHandler(this, &Form1::bntingresar_Click);
			// 
			// bntcalcular
			// 
			this->bntcalcular->Location = System::Drawing::Point(288, 280);
			this->bntcalcular->Name = L"bntcalcular";
			this->bntcalcular->Size = System::Drawing::Size(75, 23);
			this->bntcalcular->TabIndex = 6;
			this->bntcalcular->Text = L"calcular";
			this->bntcalcular->UseVisualStyleBackColor = true;
			this->bntcalcular->Click += gcnew System::EventHandler(this, &Form1::bntcalcular_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(69, 124);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 7;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"numeros";
			this->Column1->Name = L"Column1";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(21, 290);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(50, 13);
			this->label3->TabIndex = 8;
			this->label3->Text = L"promedio";
			// 
			// txtpromedio
			// 
			this->txtpromedio->Location = System::Drawing::Point(116, 287);
			this->txtpromedio->Name = L"txtpromedio";
			this->txtpromedio->Size = System::Drawing::Size(100, 20);
			this->txtpromedio->TabIndex = 9;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(632, 327);
			this->Controls->Add(this->txtpromedio);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->bntcalcular);
			this->Controls->Add(this->bntingresar);
			this->Controls->Add(this->txtnumero);
			this->Controls->Add(this->txttamanio);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->bntdefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void bntdefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tama;
				 tama=Convert::ToInt32(txttamanio->Text);
				 Grid->RowCount=tama;  
		 }
private: System::Void bntingresar_Click(System::Object^  sender, System::EventArgs^  e) {
                 int numero;
				 numero=Convert::ToDouble(txtnumero->Text);
				 promedio1.Set_Vector(numero,posi);
				 Grid->Rows[posi]->Cells[0]->Value=numero;
			     posi++;

		 }
private: System::Void bntcalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			   
			   double prom;
				prom=promedio1.PromedioVector(posi);
				txtpromedio->Text=Convert::ToString(prom);
			 
		 }
};
}

