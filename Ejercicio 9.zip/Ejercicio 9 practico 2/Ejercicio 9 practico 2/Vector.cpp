#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
using namespace std;


Vector::Vector(void)
{
	vec1[50]=0;
	vec2[50]=0;
	vec3[100]=0;
	n1=0;
	n2=0;
	n3=0;
}
Vector::~Vector(void)
{
}
void Vector::cargarvector(int vec[], int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<"V["<<i<<"]=";
		cin>>vec[i];
	}
}
void Vector::mostrarvector(int vec[], int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<"["<<vec[i]<<"]"<<" ";

	}
	cout<<endl;
}
void Vector::concatenarvector(int vec3[], int vec1[],int n1,int vec2[], int n2)
{
 int i=0;
 int j=0;
 while(i<n1)
 {
	 vec3[i]=vec1[i];
	 i++;
 }
 while(j<n2)
 {
	 vec3[i]=vec2[j];
	 i++;
	 j++;
 }
}

