#pragma once
#include "Menor.h"
#include <iostream>
namespace Practico2Ej2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Menor menor1;
	int posicion=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::TextBox^  txtMenor;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->txtMenor = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(32, 35);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 84);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(32, 310);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(37, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Menor";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(125, 32);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(107, 20);
			this->txtTamano->TabIndex = 3;
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(125, 81);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(107, 20);
			this->txtNumero->TabIndex = 4;
			// 
			// txtMenor
			// 
			this->txtMenor->Location = System::Drawing::Point(125, 307);
			this->txtMenor->Name = L"txtMenor";
			this->txtMenor->Size = System::Drawing::Size(107, 20);
			this->txtMenor->TabIndex = 5;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(306, 28);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(63, 26);
			this->button1->TabIndex = 6;
			this->button1->Text = L"Definir";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(306, 77);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(63, 26);
			this->button2->TabIndex = 7;
			this->button2->Text = L"Ingresar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(306, 303);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(63, 26);
			this->button3->TabIndex = 8;
			this->button3->Text = L"Mostrar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(67, 130);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(485, 361);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtMenor);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
               int tam;
			   tam=Convert::ToInt32(txtTamano->Text);
			   Grid->RowCount=tam;
			 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 double numero;
			 numero=Convert::ToDouble(txtNumero->Text);
			 menor1.Set_Vector(numero, posicion);
			 Grid->Rows[posicion]->Cells[0]->Value=numero;
			 posicion++;
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 double men;
			 men=menor1.Calcular(posicion);
			 txtMenor->Text=Convert::ToString(men);
		 }
};
}

