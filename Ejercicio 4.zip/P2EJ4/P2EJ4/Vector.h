#pragma once
#include <iostream>
#define MAX 10

using namespace std;
class Vector
{
private:
	int vec[MAX];
	int vec2[MAX];
	int tamano;

public:
	Vector(void);
	
	int Get_vec (int posicion);
	void Set_vec (int elemento, int posicion);
	int Get_vec2 (int posicion);
	void Set_vec2 (int elemento, int posicion);

	int Get_tamano();
	void Set_tamano(int elemento);
	void Ordenar (int tam);
};
