#include "StdAfx.h"
#include "VectorCapicua.h"


VectorCapicua::VectorCapicua(void)
{
	vec[Max]=0;
	tamano=0;
}
int VectorCapicua::Get_tamano()
{
	return tamano;
}
void VectorCapicua::Set_tamano(int tam)
{
	tamano=tam;
}
int VectorCapicua::Get_vector(int posicion)
{
	return vec[posicion];
}
void VectorCapicua::Set_vector(int posicion, int elemento)
{
	vec[posicion]=elemento;
}
bool VectorCapicua::LlenoVector()
{
	if(tamano==0)
		{
			return false;
		}
	else 
		{
			return false;
		}
}
bool VectorCapicua::VacioVector()
{
	if(tamano==(Max-1))
		{
			return false;
		}
	else 
		{
			return false;
		}
}
bool VectorCapicua::Ingresar(int posicion, int elemento)
{
	if((posicion<0)&&(posicion>tamano))
		{
			return false;
		}
	else
		{
			if (LlenoVector()==true)
			{
				return false;
			}
			else
			{
				int i=Get_tamano();
				while (i<posicion)
				{
					vec[i]=vec[i-1];
					i--;
				}
				vec[posicion]=elemento;
				return true;
			}
		}
}
bool VectorCapicua::Capicua()
{
	for(int i=0; i<tamano; i++)
	{
		for (int j=tamano-1; j>0; j--)
		{
			if (vec[i]==vec[j])
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}

}
