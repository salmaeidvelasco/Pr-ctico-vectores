#pragma once
#define Max 100
class VectorCapicua
{
private:
	int vec[Max];
	int tamano;
public:
	VectorCapicua(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vector(int posicion);
	void Set_vector(int posicion, int elemento);
	bool LlenoVector();
	bool VacioVector();
	bool Ingresar(int posicion, int elemento);
	bool Capicua();

};

