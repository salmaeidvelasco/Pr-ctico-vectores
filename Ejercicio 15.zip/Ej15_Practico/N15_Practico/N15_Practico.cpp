// N15_Practico.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "Vector.h" 

#define MAX 100
#define NAX 20

using namespace std;

void main(){

	int vec[MAX], n,  op;  
	Vector vector1;  
	do {
		cout<<"Ingrese la cantidad de alumnos: ";
		cin>>n;
	} while ((n>MAX) || (n<=0));
	do{
		cout<<"-----       M E N U        -----"<<endl;
		cout<<"|1.- Cargar Notas            |"<<endl;
		cout<<"|2.- Mejores 3 notas           |"<<endl;
		cout<<"|0.- Salir                     |"<<endl;
		cout<<"--------------------------------"<<endl;
		cout<<" Elija una opcion"<<endl;
		cin>>op;
		switch(op){
		case 1:
			cout<<"introducir notas: "<<endl;
			vector1.cargarVector(vec, n);  
			break;
		case 2:
			vector1.ordenarVector(vec, n);
			break;
		case 0: 
			cout<<"Salir"<<endl;
			break;
		default:
			cout<<"Error: Opcion no valida..."<<endl;
			break;
		}
	}while(op!=0);
	
}