#pragma once
class Vector
{
private:
	int vec[100], n;
public:
	Vector(void); 
	~Vector(void); 

	void cargarVector(int vec[], int n); 
	void ordenarVector(int vec[], int n);
};
